import numpy as np, json
from scipy.optimize import brentq
from scipy.special import erf
from thaw_model import *
out={}
# A. Stefan (Neumann) verification: homogeneous half-space, constant surface temp
k,C,th=0.5,1600*1200,0.25; Ts_=5.0; band=0.02
lay=[("Soil",0.0,k,1600,1200,th)]
r=simulate(layers=lay,forcing_fn=lambda h:Ts_,init_fn=lambda z:np.full_like(z,-band),t_deep=-band,depth=3.0,dz=0.005,band=band,hours=120,rec_every_s=600)
St=C*Ts_/(LATENT*th); lam=brentq(lambda l:l*np.exp(l*l)*erf(l)-St/np.sqrt(np.pi),1e-6,3)
X=2*lam*np.sqrt(k/C*120*3600)
out["stefan"]=dict(analytic=X,numeric=float(r["depth"][-1]),err_pct=float(100*(r["depth"][-1]-X)/X))
# B. grid convergence
out["grid"]=[]
for dz in [0.05,0.025,0.0125,0.01,0.005]:
    r=simulate("extreme",dz=dz); out["grid"].append(dict(dz=dz,dt=r["dt"],d_final=float(r["depth"][-1])))
# C. scenarios
out["scen"]={}
for kind in ["extreme","peakmatched","standard"]:
    r=simulate(kind); f=forcing(kind); h=np.arange(0,120,0.01); T=f(h); ti=float(np.sum(np.clip(T,0,None))*0.01)
    out["scen"][kind]=dict(d_final=float(r["depth"][-1]),advance=float(r["depth"][-1]-r["depth"][0]),d0=float(r["depth"][0]),TI=ti,Tmin=float(T.min()),Tmax=float(T.max()))
# D. sensitivity
rows=[("Baseline (water x1.0, subgrade-top -1.0, deep -2.0 at 2 m)",{}),
("No latent heat (original assumption)",dict(latent=False)),
("Water content x0.5",dict(water_scale=0.5)),("Water content x1.5",dict(water_scale=1.5)),
("Warmer initial subgrade top (-0.3 C)",dict(t_sg0=-0.3)),("Colder initial subgrade top (-2.0 C)",dict(t_sg0=-2.0)),
("Narrow freezing band (0.25 C)",dict(band=0.25)),("Wide freezing band (1.0 C)",dict(band=1.0)),
("Original geometry (1.15 m, -4 C bottom), no latent heat",dict(latent=False,depth=1.15,t_deep=-4.0))]
out["sens"]=[]
for name,kw in rows:
    r=simulate("extreme",**kw); m=metrics(r)
    out["sens"].append(dict(name=name,**{a:(None if np.isnan(b) else float(b)) for a,b in m.items()}))
# E. duration study (sustained forcing, 21 days)
out["dur"]={}
for ws in [0.5,1.0,1.5]:
    r=simulate("sustained",hours=504,water_scale=ws,rec_every_s=300,snap_every_h=24)
    t,b,d=r["t"],r["bci"],r["depth"]
    def first(c): 
        i=np.nonzero(c)[0]; return float(t[i[0]]) if len(i) else None
    out["dur"][str(ws)]=dict(t_subgrade=first(d>=SG_TOP),t80=first(b<80),t60=first(b<60),d_end=float(d[-1]),bci_end=float(b[-1]),h80_60=None)
# F. sweep Tmin x Tmax
tmins=np.arange(-8,4.1,2); tmaxs=np.arange(8,20.1,2)
adv=np.zeros((len(tmaxs),len(tmins)))
for i,tx in enumerate(tmaxs):
    for j,tn in enumerate(tmins):
        mean,amp=(tx+tn)/2,(tx-tn)/2
        r=simulate(forcing_fn=lambda h,mean=mean,amp=amp: mean+amp*np.sin(2*np.pi*h/24-np.pi/2),rec_every_s=600)
        adv[i,j]=r["depth"][-1]-r["depth"][0]
out["sweep"]=dict(tmins=tmins.tolist(),tmaxs=tmaxs.tolist(),adv=adv.tolist())
json.dump(out,open("results.json","w"),indent=1)
print(json.dumps({k:v for k,v in out.items() if k!="sweep"},indent=1))
import numpy as np; print(np.round(adv,2))
