"""1D enthalpy-method thaw model for a four-layer highway pavement (core model)."""
import numpy as np

LATENT = 334e3 * 1000.0          # J/m3 of water (L_f * rho_w)
# name, top depth (m), k (W/m.K), rho (kg/m3), cp (J/kg.K), volumetric water content
LAYERS = [("Asphalt",       0.00, 1.05, 2300,  920, 0.00),
          ("Granular base", 0.10, 1.30, 2000,  840, 0.05),
          ("Subbase",       0.35, 0.90, 1800,  800, 0.10),
          ("Subgrade",      0.65, 0.50, 1600, 1200, 0.25)]
SG_TOP, SG_ACTIVE = 0.65, 0.50   # subgrade top depth and "active" thickness used for BCI (m)
BCI_F   = [0.00, 0.05, 0.30, 0.70, 1.00]   # thawed fraction of active subgrade
BCI_VAL = [100.0, 95.0, 45.0, 20.0, 10.0]  # Bearing Capacity Index (%)

def forcing(kind):
    """Surface temperature (degC) as a function of time in hours."""
    if kind == "extreme":   # Chinook-type: mean +8, +/-7 diurnal, +3 pulse centred at 60 h
        return lambda h: 8 + 7*np.sin(2*np.pi*h/24 - np.pi/2) + 3*np.exp(-(h-60)**2/800)
    if kind == "sustained":  # extreme mean/diurnal range without the pulse (used for duration studies)
        return lambda h: 8 + 7*np.sin(2*np.pi*h/24 - np.pi/2)
    if kind == "standard":  # warm days, freezing nights: -5 .. +9
        return lambda h: 2 + 7*np.sin(2*np.pi*h/24 - np.pi/2)
    if kind == "peakmatched":  # same daytime peak as the extreme case, freezing nights: -6 .. +15
        return lambda h: 4.5 + 10.5*np.sin(2*np.pi*h/24 - np.pi/2)
    raise ValueError(kind)

def initial_profile(z, t_sg0=-1.0, t_deep=-2.0):
    return np.interp(z, [0, 0.10, 0.35, 0.65, 2.0], [2.0, 2.0, -0.5, t_sg0, t_deep])

def bci(f):
    return np.interp(f, BCI_F, BCI_VAL)

def thaw_depth(T, z):
    """Depth (m) of the deepest 0 degC crossing (linear interpolation); 0 if nothing is thawed."""
    pos = np.nonzero(T > 0)[0]
    if len(pos) == 0: return 0.0
    i = pos[-1]
    if i == len(T) - 1: return z[-1]
    return z[i] + (z[i+1]-z[i]) * T[i] / (T[i] - T[i+1])

def simulate(kind="extreme", dz=0.01, hours=120, depth=2.0, dt=None, band=0.5, latent=True,
             water_scale=1.0, t_sg0=-1.0, t_deep=-2.0, snap_every_h=2, rec_every_s=60,
             layers=None, forcing_fn=None, init_fn=None):
    layers = LAYERS if layers is None else layers
    z = np.arange(0, depth + dz/2, dz); n = len(z)
    k = np.zeros(n); C = np.zeros(n); Lt = np.zeros(n)
    for name, top, kk, rho, cp, th in layers:
        m = z >= top - 1e-9
        k[m], C[m], Lt[m] = kk, rho*cp, (LATENT*th*water_scale if latent else 0.0)
    kh = 2*k[:-1]*k[1:]/(k[:-1]+k[1:])                 # harmonic-mean interface conductivity
    dt_max = 0.25*np.min(C*dz**2/k)                    # explicit stability (r <= 0.25 on sensible capacity)
    dt = dt_max if dt is None else min(dt, dt_max)
    dt = hours*3600/np.ceil(hours*3600/dt)             # make steps divide the run exactly
    Ca = C + Lt/band                                   # slope of H(T) inside the freezing band
    def H_of_T(T):
        return np.where(T <= -band, C*T, np.where(T >= 0, C*T + Lt, -C*band + Ca*(T+band)))
    def T_of_H(H):
        return np.where(H <= -C*band, H/C, np.where(H >= Lt, (H-Lt)/C, -band + (H + C*band)/Ca))
    Ts = forcing_fn if forcing_fn is not None else forcing(kind)
    T = init_fn(z) if init_fn is not None else initial_profile(z, t_sg0, t_deep)
    T = np.array(T, float); T[-1] = t_deep
    H = H_of_T(T)
    nsteps = int(round(hours*3600/dt)); rec = max(1, int(round(rec_every_s/dt))); snap = int(round(snap_every_h*3600/dt))
    ts, depths, snaps, snap_t = [], [], [], []
    for s in range(nsteps + 1):
        h = s*dt/3600
        T[0] = Ts(h); H[0] = H_of_T(T[:1])[0]
        if s % rec == 0:  ts.append(h); depths.append(thaw_depth(T, z))
        if s % snap == 0: snaps.append(T.copy()); snap_t.append(h)
        if s == nsteps: break
        q = kh*(T[1:] - T[:-1])/dz
        H[1:-1] += dt*(q[1:] - q[:-1])/dz
        T = T_of_H(H); T[0] = Ts((s+1)*dt/3600); T[-1] = t_deep
    ts, depths = np.array(ts), np.maximum.accumulate(np.array(depths))  # running maximum of the 0 degC front
    f = np.clip((depths - SG_TOP)/SG_ACTIVE, 0, 1)
    return dict(z=z, t=ts, depth=depths, f=f, bci=bci(f), snaps=np.array(snaps), snap_t=np.array(snap_t), dt=dt, dz=dz)

def metrics(r):
    t, d, b = r["t"], r["depth"], r["bci"]; step = t[1]-t[0]
    hit = np.nonzero(d >= SG_TOP)[0]
    return dict(t_subgrade=(t[hit[0]] if len(hit) else np.nan), d_final=d[-1], d_max=d.max(),
                bci_min=b.min(), h_below80=(b < 80).sum()*step, h_below60=(b < 60).sum()*step)
