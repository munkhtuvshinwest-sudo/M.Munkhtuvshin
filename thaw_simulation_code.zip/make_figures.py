import numpy as np, json, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.colors import Normalize, TwoSlopeNorm
from thaw_model import *
plt.rcParams.update({"font.size":9,"axes.grid":True,"grid.alpha":0.3,"figure.dpi":200,"savefig.bbox":"tight"})
res=json.load(open("results.json"))
LAYER_TOPS=[("Asphalt",0.10),("Base",0.35),("Subbase",0.65)]
base=simulate("extreme"); z=base["z"]
# Fig 1: profiles
fig,ax=plt.subplots(figsize=(6.5,4.6)); norm=Normalize(0,120); cmap=cm.RdYlBu_r
for T,t in zip(base["snaps"],base["snap_t"]): ax.plot(T,z,color=cmap(norm(t)),lw=0.9 if t not in (0,60,120) else 2.0)
ax.axvline(0,color="k",ls="--",lw=1); ax.set_ylim(1.2,0); ax.set_xlim(-4,19)
for nm,d in LAYER_TOPS: ax.axhline(d,color="grey",lw=0.7,ls=":")
for nm,y in [("Asphalt",0.05),("Base",0.22),("Subbase",0.5),("Subgrade",0.92)]: ax.text(18.7,y,nm,ha="right",va="center",fontsize=8,color="dimgrey")
ax.set_xlabel("Temperature (°C)"); ax.set_ylabel("Depth (m)")
sm=cm.ScalarMappable(norm=norm,cmap=cmap); cb=fig.colorbar(sm,ax=ax,pad=0.02); cb.set_label("Time (h)")
fig.savefig("fig1.png"); plt.close()
# Fig 2: scenarios
sc={"extreme":("Extreme (warm nights)","#c0392b"),"peakmatched":("Peak-matched (freezing nights)","#e08a1e"),"standard":("Standard (freezing nights)","#2c6fbb")}
fig,(a,b)=plt.subplots(2,1,figsize=(6.5,5.6),sharex=True,gridspec_kw={"height_ratios":[1,1.2]})
h=np.linspace(0,120,1200)
for k,(lab,c) in sc.items():
    a.plot(h,forcing(k)(h),color=c,label=lab,lw=1.4)
    r=simulate(k); b.plot(r["t"],r["depth"],color=c,lw=1.6,label=lab)
a.axhline(0,color="k",ls="--",lw=0.8); a.set_ylabel("Surface temperature (°C)"); a.legend(fontsize=7.5,loc="lower right",ncol=1)
b.set_ylim(0.8,0.25)
for nm,d in [("Base / subbase interface",0.35),("Subbase / subgrade interface (0.65 m)",0.65)]:
    b.axhline(d,color="grey",lw=0.8,ls=":"); b.text(1,d-0.012,nm,fontsize=7.5,color="dimgrey",va="bottom")
b.set_ylabel("Maximum thaw depth (m)"); b.set_xlabel("Time (h)")
a.text(0.01,0.93,"A",transform=a.transAxes,fontweight="bold",va="top"); b.text(0.01,0.07,"B",transform=b.transAxes,fontweight="bold",va="bottom")
fig.tight_layout(); fig.savefig("fig3.png"); plt.close()
# Fig 3: heatmap
fig,ax=plt.subplots(figsize=(6.5,3.6))
S=base["snaps"].T; m=z<=1.2
norm=TwoSlopeNorm(vmin=-3,vcenter=0,vmax=16)
im=ax.pcolormesh(base["snap_t"],z[m],S[m],cmap="RdBu_r",norm=norm,shading="auto")
ax.plot(base["t"],base["depth"],"k--",lw=1.2,label="Thaw front (0 °C isotherm)")
for nm,d in LAYER_TOPS: ax.axhline(d,color="white",lw=0.7,ls=":")
ax.set_ylim(1.2,0); ax.set_xlim(0,120); ax.set_xlabel("Time (h)"); ax.set_ylabel("Depth (m)"); ax.legend(loc="lower right",fontsize=7.5); ax.grid(False)
cb=fig.colorbar(im,ax=ax,pad=0.02); cb.set_label("Temperature (°C)")
fig.savefig("fig2.png"); plt.close()
# Fig 4: duration study
fig,(a,b)=plt.subplots(2,1,figsize=(6.5,5.6),sharex=True)
cols={0.5:"#2c6fbb",1.0:"#222222",1.5:"#c0392b"}
for ws in [0.5,1.0,1.5]:
    r=simulate("sustained",hours=504,water_scale=ws,rec_every_s=300,snap_every_h=24)
    lab=f"Water content ×{ws}"+(" (baseline)" if ws==1.0 else "")
    a.plot(r["t"]/24,r["depth"],color=cols[ws],label=lab,lw=1.5); b.plot(r["t"]/24,r["bci"],color=cols[ws],lw=1.5)
a.axhline(SG_TOP,color="grey",ls=":",lw=0.9); a.text(0.2,SG_TOP-0.01,"Subgrade top (0.65 m)",fontsize=7.5,color="dimgrey",va="bottom")
a.set_ylim(1.0,0.3); a.set_ylabel("Thaw front depth (m)"); a.legend(fontsize=7.5,loc="lower left")
b.axhline(80,color="#e08a1e",ls="--",lw=1); b.axhline(60,color="#c0392b",ls="--",lw=1)
b.text(20.9,81,"Load restriction (80%)",ha="right",fontsize=7.5,color="#e08a1e"); b.text(20.9,61,"Road closure (60%)",ha="right",fontsize=7.5,color="#c0392b")
b.set_ylabel("BCI (%)"); b.set_xlabel("Time (days)"); b.set_ylim(0,105)
a.text(0.01,0.93,"A",transform=a.transAxes,fontweight="bold",va="top"); b.text(0.01,0.07,"B",transform=b.transAxes,fontweight="bold",va="bottom")
fig.tight_layout(); fig.savefig("fig4.png"); plt.close()
# Fig 5: sweep
sw=res["sweep"]; X,Y=np.meshgrid(sw["tmins"],sw["tmaxs"]); A=np.array(sw["adv"])
fig,ax=plt.subplots(figsize=(6.0,4.3))
cs=ax.contourf(X,Y,A*100,levels=np.arange(0,32,2),cmap="YlOrRd"); cb=fig.colorbar(cs,ax=ax); cb.set_label("Thaw front advance in 120 h (cm)")
mean=(X+Y)/2; ls=ax.contour(X,Y,mean,levels=[0,2,4,6,8,10],colors="k",linewidths=0.6,linestyles="--")
ax.clabel(ls,fmt=lambda v:f"mean {v:.0f} °C",fontsize=7)
for k,(lab,c) in sc.items():
    f=forcing(k)(np.linspace(0,24,2400)) if k!="extreme" else None
    tn,tx=(1.0,15.0) if k=="extreme" else ((-6,15) if k=="peakmatched" else (-5,9))
    ax.plot(tn,tx,"o",color="white",mec="k",ms=7); ax.annotate({"extreme":"Extreme*","peakmatched":"Peak-matched","standard":"Standard"}[k],(tn,tx),xytext=(5,-12),textcoords="offset points",fontsize=7.5)
ax.set_xlabel("Nightly minimum temperature (°C)"); ax.set_ylabel("Daily maximum temperature (°C)"); ax.grid(False)
fig.savefig("fig5.png"); plt.close()
print("ok")
